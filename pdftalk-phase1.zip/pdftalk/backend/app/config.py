"""
app/config.py
=============
Single source of truth for all environment-backed configuration.

Pydantic BaseSettings reads from the .env file automatically and raises
a clear ValidationError at startup if any required field is missing.
This means bad config is caught immediately on boot — not when a user
hits a broken endpoint.

Usage anywhere in the app:
    from app.config import settings
    print(settings.DATABASE_URL)
"""

from functools import lru_cache
from typing import Literal

from pydantic import AnyHttpUrl, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
    )

    # -------------------------------------------------------------------------
    # Database
    # -------------------------------------------------------------------------
    DATABASE_URL: str

    # -------------------------------------------------------------------------
    # Redis
    # -------------------------------------------------------------------------
    REDIS_URL: str

    # -------------------------------------------------------------------------
    # Auth
    # -------------------------------------------------------------------------
    JWT_SECRET: str
    JWT_EXPIRE_MINUTES: int = 60

    @field_validator("JWT_SECRET")
    @classmethod
    def jwt_secret_min_length(cls, v: str) -> str:
        if len(v) < 32:
            raise ValueError(
                "JWT_SECRET must be at least 32 characters. "
                "Generate one with: openssl rand -hex 32"
            )
        return v

    # -------------------------------------------------------------------------
    # OpenAI
    # -------------------------------------------------------------------------
    OPENAI_API_KEY: str
    OPENAI_CHAT_MODEL: str = "gpt-4o-mini"
    OPENAI_EMBEDDING_MODEL: str = "text-embedding-3-small"

    # -------------------------------------------------------------------------
    # AWS S3
    # -------------------------------------------------------------------------
    AWS_ACCESS_KEY_ID: str
    AWS_SECRET_ACCESS_KEY: str
    AWS_REGION: str = "ap-south-1"
    S3_BUCKET_NAME: str

    # -------------------------------------------------------------------------
    # Email
    # -------------------------------------------------------------------------
    SMTP_HOST: str
    SMTP_PORT: int = 587
    SMTP_USER: str
    SMTP_PASSWORD: str
    EMAIL_FROM: str = "noreply@pdftalk.com"

    # -------------------------------------------------------------------------
    # App
    # -------------------------------------------------------------------------
    APP_URL: AnyHttpUrl
    APP_ENV: Literal["development", "staging", "production"] = "development"

    @property
    def is_production(self) -> bool:
        return self.APP_ENV == "production"

    @property
    def is_development(self) -> bool:
        return self.APP_ENV == "development"

    # -------------------------------------------------------------------------
    # Rate limits / quotas
    # -------------------------------------------------------------------------
    MAX_DOCS_PER_USER: int = 20
    MAX_DAILY_TOKENS_PER_USER: int = 100_000


@lru_cache
def get_settings() -> Settings:
    """
    Returns a cached Settings instance.
    Use as a FastAPI dependency: settings: Settings = Depends(get_settings)
    Or import directly: from app.config import settings
    """
    return Settings()


# Module-level singleton — raises immediately if any required field is missing.
# This is intentional: fail fast at import time, not at first use.
settings = get_settings()
