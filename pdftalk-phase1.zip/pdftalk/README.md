# PDFTalk

Upload a PDF. Ask it anything.

PDFTalk is a full-stack RAG (Retrieval-Augmented Generation) application that lets users upload PDF documents and have natural-language conversations with their content. Built with FastAPI, Next.js, pgvector, and OpenAI.

---

## Architecture

```
browser
  └── Next.js (frontend/)
        └── FastAPI (backend/)
              ├── PostgreSQL + pgvector  (document storage + embeddings)
              ├── Redis                  (job queue + caching)
              └── Celery worker          (async PDF processing)
```

---

## Quick start

### Prerequisites

- Docker & Docker Compose
- `uv` — `curl -LsSf https://astral.sh/uv/install.sh | sh`
- `pnpm` — `npm install -g pnpm`
- `make`

### 1. Clone and configure

```bash
git clone https://github.com/your-org/pdftalk.git
cd pdftalk

# Copy env templates and fill in real values
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env.local
```

Open `backend/.env` and fill in at minimum:
- `OPENAI_API_KEY`
- `JWT_SECRET` (generate: `openssl rand -hex 32`)
- All SMTP fields if you want email

### 2. Start the stack

```bash
make dev
```

This starts: Postgres, Redis, FastAPI (hot-reload), Celery worker, Nginx.

- API: http://localhost:8000
- Frontend: http://localhost:3000
- API docs: http://localhost:8000/docs

### 3. Run tests

```bash
make test
```

---

## Project structure

```
pdftalk/
├── backend/                  # FastAPI application
│   ├── app/
│   │   ├── main.py           # App entry point
│   │   ├── config.py         # Pydantic Settings
│   │   ├── api/              # Route handlers
│   │   ├── services/         # Business logic
│   │   ├── models/           # SQLAlchemy models
│   │   └── worker/           # Celery tasks
│   ├── tests/
│   ├── pyproject.toml
│   └── .env.example
│
├── frontend/                 # Next.js application
│   ├── app/                  # App router pages
│   ├── components/
│   ├── lib/
│   ├── package.json
│   └── .env.example
│
├── docker-compose.dev.yml    # Full local dev stack
├── Makefile                  # Dev shortcuts
└── README.md
```

---

## Common commands

| Command | What it does |
|---|---|
| `make dev` | Start full local stack |
| `make dev-down` | Stop all containers |
| `make test` | Run all tests |
| `make lint` | Lint backend + frontend |
| `make format` | Auto-format all code |
| `make dev-db` | Open psql shell |
| `make dev-redis` | Open redis-cli shell |
| `make secrets-scan` | Scan for leaked secrets |

---

## Environment variables

See [`backend/.env.example`](backend/.env.example) and [`frontend/.env.example`](frontend/.env.example) for the full list with documentation.

---

## License

MIT — see [LICENSE](LICENSE)
