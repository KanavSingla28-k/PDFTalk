/**
 * lib/env.ts
 * ==========
 * Validates all environment variables at startup using zod.
 * Import `env` from here instead of accessing process.env directly.
 *
 * If a required variable is missing, this throws immediately when the
 * module is first imported — during build or server startup — not
 * silently at runtime.
 *
 * Usage:
 *   import { env } from '@/lib/env'
 *   console.log(env.NEXT_PUBLIC_API_URL)
 */

import { z } from 'zod'

const envSchema = z.object({
  // API
  NEXT_PUBLIC_API_URL: z
    .string()
    .url('NEXT_PUBLIC_API_URL must be a valid URL (e.g. http://localhost:8000)'),

  // App
  NEXT_PUBLIC_APP_URL: z
    .string()
    .url('NEXT_PUBLIC_APP_URL must be a valid URL'),

  NEXT_PUBLIC_APP_NAME: z.string().min(1).default('PDFTalk'),

  // Node environment (injected by Next.js automatically)
  NODE_ENV: z
    .enum(['development', 'test', 'production'])
    .default('development'),
})

// Parse and validate. Throws a ZodError with a clear message on failure.
const parsed = envSchema.safeParse({
  NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL,
  NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
  NEXT_PUBLIC_APP_NAME: process.env.NEXT_PUBLIC_APP_NAME,
  NODE_ENV: process.env.NODE_ENV,
})

if (!parsed.success) {
  console.error('❌ Invalid environment variables:\n')
  parsed.error.issues.forEach((issue) => {
    console.error(`  ${issue.path.join('.')}: ${issue.message}`)
  })
  console.error('\nCheck frontend/.env.local against frontend/.env.example\n')
  throw new Error('Environment variable validation failed — see above.')
}

export const env = parsed.data
export type Env = typeof env
